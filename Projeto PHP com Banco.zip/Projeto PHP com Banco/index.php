<?php
 session_start();
?>
<!DOCTYPE HTML>
	<!-- Programa para trabalhar em uma oficina -->
	<!-- Criado por Alyson Antonio DATA 27/02/18 as 21:40 -->
<html lang="pt-br">
	<head>
		<title> Projeto Oficina </title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/style.css" />

		<!--[if lt IE 9]>
			<script src="bower_components/html5shiv/dist/html5shiv.js"></script>
		<![endif]-->
	</head>

	<body>

		<!-- Chamando um alerta quando a mensagem no cadastros der error ou cadastras o funcionario etc-->
	<?php
		if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
		}
	?>


	<!-- Menu Basico apenas para controlar as paginas!-->
		<nav>	
			<ul id="btn">
				<li> <a>Cadastro</a>
					<ul>	
						<li> <a href="paginas/cadastro.php" >Cadastro - Clientes</a></li>
						<li> <a href="paginas/produtos.php" >Cadastro - Produtos</a></li>
						<li> <a href="paginas/fornecedor.php" >Cadastro - Fornecedores</a></li>
						<li> <a href="paginas/funcionarios.php" >Cadastro - Funcionarios</a></li>
						<li> <a href="#" >Cadastro - Ordem de Serviços</a></li>
						<li> <a href="#" >Cadastro - Ordem de Vendas</a></li>
						<li> <a href="#" >Cadastro - de Despesas</a></li>
					</ul>	
				</li>
			</ul>
			<ul id="btn">
				<li> <a>Relatorio </a>
					<ul>
						<li> <a href="#" >Relatorio - Pagamentos</a></li>
						<li> <a href="#" >Relatorio - Lucros</a></li>
						<li> <a href="#" >Relatorio - Estoque</a></li>
						<li> <a href="paginas/relatorio-funcionarios.php" >Relatorio - Funcionarios</a></li>
						<li> <a href="paginas/relatorio-fornecedor.php" >Relatorio - Fornecedores</a></li>
						<li> <a href="paginas/relatorio-clientes.php" >Relatorio - Clientes</a></li>
					</ul>
				</li>
				</ul>
				</ul>
		</nav>
	</body>
	
</html>