	<!-- Programa para trabalhar em uma oficina -->
	<!-- Criado por Alyson Antonio DATA 27/02/18 as 21:40 -->


	<!-- Incluindo no banco de dados MYSQL os formularios ... -->
<?php
	session_start();
	include_once("../conectar/conexao.php");

	$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
	$re = filter_input(INPUT_POST, 're', FILTER_SANITIZE_STRING);
	$funcao = filter_input(INPUT_POST, 'funcao', FILTER_SANITIZE_STRING);
	$salario = filter_input(INPUT_POST, 'salario', FILTER_SANITIZE_STRING);
	$data_admissao = filter_input(INPUT_POST, 'data_admissao', FILTER_SANITIZE_STRING);
	$endereco = filter_input(INPUT_POST, 'endereco', FILTER_SANITIZE_STRING);
	$telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);
	$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
	

	$result_usuario = "INSERT INTO funcionarios (nome, re, funcao, salario, data_admissao, endereco, telefone, email) 
		VALUES ('$nome', '$re', '$funcao', '$salario', '$data_admissao', '$endereco', '$telefone', '$email')";

	$resultado_usuario = mysqli_query($conn, $result_usuario);
//Quando incluir no banco de dados aparecer msg de error ou nao .
if(mysqli_insert_id($conn)){
	$_SESSION['mensagem'] = "<p style='color:green;'>Cliente fornecedor com sucesso.</p>";
	header("Location: funcionarios.php");

}else
	$_SESSION['mensagem'] = "<p style='color:red;'>Cliente nao foi fornecedor com sucesso.</p>";
	header("Location: funcionarios.php");

?>