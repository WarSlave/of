<?php
 session_start();
?>

<!DOCTYPE HTML>
	<!-- Programa para trabalhar em uma oficina -->
	<!-- Criado por Alyson Antonio DATA 27/02/18 as 21:40 -->
<html lang="pt-br">
	<head>
		<title> Projeto Oficina </title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/style.css" />

		<!--[if lt IE 9]>
			<script src="bower_components/html5shiv/dist/html5shiv.js"></script>
		<![endif]-->
	</head>

	<body>
		<h1>Cadastro de Funcionarios</h1>
<?php
	if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
	}
?>

		<form name="cCliente" method="POST" action="processo-funcionario.php">
			<label>Nome:</label><br>
				<input type="text" name="nome" id="nome" placeholder="Digite o nome do funcionario." required /><br><br>
			<label>RE:</label><br>
				<input type="text" name="cpf" id="re" placeholder="Digite o re do funcionario" required maxlength="14" /><br><br>
			<label>Funçao:</label><br>
				<input type="text" name="funcao" id="funcao" placeholder="Digite sua Funçao" required /><br><br>
			<label>Salario:</label><br>
				<input type="number" name="salario" id="salario" placeholder="Digite o Salario." required /><br><br>
			<label>Data Admissao:</label><br>
				<input type="date" name="data_admissao" id="data_admissao"/><br><br>
			<label>Endereço:</label><br>
				<input type="text" name="endereco" id="endereco" placeholder="Digite seu Endereço." required /><br><br>
			<label>Telefone:</label><br>
				<input type="text" name="telefone" id="telefone" placeholder="Digite seu Telefone." required /><br><br>
			<label>E-mail:</label><br>
				<input type="email" name="email" id="email" placeholder="Digite seu E-mail." required /><br><br>
			
			<input type="submit" name="Enviar" value="Cadastrar"/>
			<a href="../index.php">Voltar</a>	
		</form>
	
	</body>
	
</html>