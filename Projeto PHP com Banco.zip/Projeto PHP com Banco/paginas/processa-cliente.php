	<!-- Programa para trabalhar em uma oficina -->
	<!-- Criado por Alyson Antonio DATA 27/02/18 as 21:40 -->


	<!-- Incluindo no banco de dados MYSQL os formularios ... -->


<?php
	session_start();
	include_once("../conectar/conexao.php");

	$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
	$cpf = filter_input(INPUT_POST, 'cpf', FILTER_SANITIZE_STRING);
	$endereco = filter_input(INPUT_POST, 'endereco', FILTER_SANITIZE_STRING);
	$telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);
	$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
	$data_nasc = filter_input(INPUT_POST, 'data_nasc', FILTER_SANITIZE_STRING);
	$msg = filter_input(INPUT_POST, 'msg', FILTER_SANITIZE_STRING);

	$result_usuario = "INSERT INTO cadastro_cliente (nome, cpf, endereco, telefone, email, data_nasc, msg) VALUES ('$nome', '$cpf', '$endereco', '$telefone', '$email', '$data_nasc', '$msg')";
	$resultado_usuario = mysqli_query($conn, $result_usuario);
//Quando incluir no banco de dados aparecer msg de error ou nao .
if(mysqli_insert_id($conn)){
	$_SESSION['mensagem'] = "<p style='color:green;'>Cliente cadastrado com sucesso.</p>";
	header("Location: cadastro.php");

}else
	$_SESSION['mensagem'] = "<p style='color:red;'>Cliente nao foi cadastrado com sucesso.</p>";
	header("Location: cadastro.php");

?>